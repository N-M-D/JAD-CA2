So I've just finished the CRUD for the users. I know the website does not look pretty, but I'll work on it next week.
Attached in the zip file are all the files that I've created. You can use those to help you in your task if needed.

Things to note:
-The role of the user is stored in session storage after login
-The database connection url needs to be changed if ur testing on ur laptop

Setting up the database:
-Open the sql file into mysql. You may need to port in ur tables if you've already created them.

